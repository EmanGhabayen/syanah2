<?php
if (!defined('ABSPATH')) {
    die('Direct access forbidden.');
}

/**
 *
 * Widgets init
 *
 * @package   Listingo
 * @author    themographics
 * @link      https://themeforest.net/user/themographics/portfolio
 * @version 1.0
 * @since 1.0
 */

require plugin_dir_path( __FILE__ ).'class-ads.php';
require plugin_dir_path( __FILE__ ).'class-recent-posts-widget.php';
require plugin_dir_path( __FILE__ ).'class-about-us-widget.php';
require plugin_dir_path( __FILE__ ).'class-tweets-widget.php';
require plugin_dir_path( __FILE__ ).'class-recent-questions.php';
require plugin_dir_path( __FILE__ ).'class-answers-questions-statics.php';


